Poll (from core) module for Drupal 8
====================================

Implementation of the poll module that was removed from Drupal 8 core. Poll is an entity with a Poll Choice field type to encapsulate each choice option and the initial vote. 
